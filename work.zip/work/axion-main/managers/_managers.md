folder naming snake_case 
file naming CamelCase 
do not include manager in the folder or the file 