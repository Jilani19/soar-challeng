module.exports = {
    createStudent: [
        {
            model: 'firstName',
            required: true,
        },
        {
            model: 'lastName',
            required: true,
        },
        {
            model: 'dateOfBirth',
            required: true,
        },
        {
            model: 'schoolId',
            required: true,
        },
        {
            model: 'classroomId',
            required: true,
        },
        {
            model: 'guardianEmail',
            required: true,
        },
        {
            model: 'guardianPhone',
            required: true,
        }
    ],
    updateStudent: [
        {
            model: 'firstName',
            required: false,
        },
        {
            model: 'lastName',
            required: false,
        },
        {
            model: 'classroomId',
            required: false,
        },
        {
            model: 'guardianEmail',
            required: false,
        },
        {
            model: 'guardianPhone',
            required: false,
        }
    ],
    transferStudent: [
        {
            model: 'newSchoolId',
            required: true,
        },
        {
            model: 'newClassroomId',
            required: true,
        }
    ]
} 