const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    dateOfBirth: {
        type: Date,
        required: true
    },
    schoolId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'School',
        required: true
    },
    classroomId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Classroom',
        required: true
    },
    guardianEmail: {
        type: String,
        required: true,
        lowercase: true,
        trim: true
    },
    guardianPhone: {
        type: String,
        required: true
    },
    enrollmentDate: {
        type: Date,
        default: Date.now
    },
    status: {
        type: String,
        enum: ['active', 'inactive', 'transferred'],
        default: 'active'
    },
    transferHistory: [{
        fromSchool: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'School'
        },
        toSchool: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'School'
        },
        date: {
            type: Date,
            default: Date.now
        }
    }]
}, {
    timestamps: true
});

// Add indexes for efficient queries
studentSchema.index({ schoolId: 1, classroomId: 1 });
studentSchema.index({ guardianEmail: 1 });

module.exports = mongoose.model('Student', studentSchema); 