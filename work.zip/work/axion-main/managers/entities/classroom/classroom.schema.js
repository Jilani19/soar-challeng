module.exports = {
    createClassroom: [
        {
            model: 'name',
            required: true,
        },
        {
            model: 'schoolId',
            required: true,
        },
        {
            model: 'capacity',
            required: true,
        },
        {
            model: 'grade',
            required: true,
        },
        {
            model: 'section',
            required: true,
        }
    ],
    updateClassroom: [
        {
            model: 'name',
            required: false,
        },
        {
            model: 'capacity',
            required: false,
        },
        {
            model: 'grade',
            required: false,
        },
        {
            model: 'section',
            required: false,
        }
    ]
} 