module.exports = {
    createUser: [
        {
            model: 'username',
            required: true,
        },
        {
            model: 'password',
            required: true,
        },
        {
            model: 'email',
            required: true,
        },
        {
            model: 'role',
            required: true,
            oneOf: ['superadmin', 'school_admin']
        },
        {
            model: 'schoolId',
            required: false, // Required only for school_admin
        }
    ],
    updateUser: [
        {
            model: 'username',
            required: false,
        },
        {
            model: 'email',
            required: false,
        },
        {
            model: 'password',
            required: false,
        }
    ],
    login: [
        {
            model: 'username',
            required: true,
        },
        {
            model: 'password',
            required: true,
        }
    ]
}


