module.exports = {
    createSchool: [
        {
            model: 'name',
            required: true,
        },
        {
            model: 'address',
            required: true,
        },
        {
            model: 'contactEmail',
            required: true,
        },
        {
            model: 'contactPhone',
            required: true,
        },
        {
            model: 'adminId',
            required: true,
        }
    ],
    updateSchool: [
        {
            model: 'name',
            required: false,
        },
        {
            model: 'address',
            required: false,
        },
        {
            model: 'contactEmail',
            required: false,
        },
        {
            model: 'contactPhone',
            required: false,
        }
    ]
} 