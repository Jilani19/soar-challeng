const config                = require('./config/index.config.js');
const Cortex                = require('ion-cortex');
const ManagersLoader        = require('./loaders/ManagersLoader.js');
const Aeon                  = require('aeon-machine');
const winston               = require('winston');

// Configure Winston logger
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/combined.log' })
    ]
});

if (process.env.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        format: winston.format.simple()
    }));
}

// Global error handlers
process.on('uncaughtException', err => {
    logger.error('Uncaught Exception:', { error: err.message, stack: err.stack });
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.error('Unhandled Rejection:', { reason: reason, promise: promise });
    process.exit(1);
});

// Initialize cache
const cache = require('./cache/cache.dbh')({
    prefix: config.dotEnv.CACHE_PREFIX,
    url: config.dotEnv.CACHE_REDIS
});

// Initialize Oyster DB
const Oyster = require('oyster-db');
const oyster = new Oyster({
    url: config.dotEnv.OYSTER_REDIS,
    prefix: config.dotEnv.OYSTER_PREFIX
});

// Initialize Cortex
const cortex = new Cortex({
    prefix: config.dotEnv.CORTEX_PREFIX,
    url: config.dotEnv.CORTEX_REDIS,
    type: config.dotEnv.CORTEX_TYPE,
    state: () => {
        return {}
    },
    activeDelay: "50",
    idlDelay: "200",
});

// Initialize Aeon
const aeon = new Aeon({
    cortex,
    timestampFrom: Date.now(),
    segmantDuration: 500
});

// Initialize Managers
const managersLoader = new ManagersLoader({ config, cache, cortex, oyster, aeon });
const managers = managersLoader.load();

// Start the server
const startServer = async () => {
    try {
        // Connect to MongoDB
        if (config.dotEnv.MONGO_URI) {
            await require('./connect/mongo')({ uri: config.dotEnv.MONGO_URI });
        }

        // Start the user server
        await managers.userServer.run();
        logger.info('Server started successfully');
    } catch (error) {
        logger.error('Failed to start server:', { error: error.message });
        process.exit(1);
    }
};

startServer();
