/**
 * @swagger
 * tags:
 *   name: Schools
 *   description: School management endpoints
 */

const express = require('express');
const router = express.Router();

/**
 * @swagger
 * /api/schools:
 *   get:
 *     tags: [Schools]
 *     summary: Get all schools
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of schools
 *       401:
 *         description: Unauthorized
 */
router.get('/', async (req, res) => {
    // Implementation will be in the school manager
});

/**
 * @swagger
 * /api/schools:
 *   post:
 *     tags: [Schools]
 *     summary: Create a new school
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - address
 *               - contactEmail
 *               - contactPhone
 *               - adminId
 *             properties:
 *               name:
 *                 type: string
 *               address:
 *                 type: string
 *               contactEmail:
 *                 type: string
 *               contactPhone:
 *                 type: string
 *               adminId:
 *                 type: string
 *     responses:
 *       201:
 *         description: School created successfully
 *       400:
 *         description: Invalid input
 *       401:
 *         description: Unauthorized
 */
router.post('/', async (req, res) => {
    // Implementation will be in the school manager
});

/**
 * @swagger
 * /api/schools/{id}:
 *   get:
 *     tags: [Schools]
 *     summary: Get school by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: School details
 *       404:
 *         description: School not found
 */
router.get('/:id', async (req, res) => {
    // Implementation will be in the school manager
});

/**
 * @swagger
 * /api/schools/{id}:
 *   put:
 *     tags: [Schools]
 *     summary: Update school
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               address:
 *                 type: string
 *               contactEmail:
 *                 type: string
 *               contactPhone:
 *                 type: string
 *     responses:
 *       200:
 *         description: School updated successfully
 *       400:
 *         description: Invalid input
 *       404:
 *         description: School not found
 */
router.put('/:id', async (req, res) => {
    // Implementation will be in the school manager
});

/**
 * @swagger
 * /api/schools/{id}:
 *   delete:
 *     tags: [Schools]
 *     summary: Delete school
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: School deleted successfully
 *       404:
 *         description: School not found
 */
router.delete('/:id', async (req, res) => {
    // Implementation will be in the school manager
});

module.exports = router; 