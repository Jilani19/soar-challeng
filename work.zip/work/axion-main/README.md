# School Management System API

A comprehensive RESTful API service for managing schools, classrooms, and students with role-based access control, built using the Axion template.

## System Architecture

- **Backend**: Node.js with Express.js
- **Database**: MongoDB for data persistence
- **Caching**: Redis for caching and rate limiting
- **Authentication**: JWT-based with role-based access control (RBAC)
- **Documentation**: Swagger/OpenAPI

## Features

- Role-based access control (RBAC)
  - Superadmin: Full system access
  - School Administrator: School-specific access
- Complete CRUD operations for:
  - Schools
  - Classrooms
  - Students
- Student transfer management
- Input validation and error handling
- API rate limiting
- Comprehensive API documentation
- Logging system

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- Redis (v6 or higher)
- Git

## Project Structure

```
axion-main/
├── app.js                  # Express application setup
├── index.js               # Server initialization
├── .env                   # Environment variables
├── package.json           # Project dependencies
├── routes/                # API routes
│   ├── auth.routes.js     # Authentication routes
│   ├── school.routes.js   # School management routes
│   ├── classroom.routes.js # Classroom management routes
│   └── student.routes.js  # Student management routes
├── managers/              # Business logic
│   ├── entities/          # Entity managers
│   │   ├── school/       # School-related logic
│   │   ├── classroom/    # Classroom-related logic
│   │   ├── student/      # Student-related logic
│   │   └── user/         # User-related logic
├── models/                # MongoDB models
│   ├── school.model.js
│   ├── classroom.model.js
│   ├── student.model.js
│   └── user.model.js
├── mws/                   # Middleware
│   ├── __rbac.mw.js      # Role-based access control
│   ├── __validator.mw.js  # Request validation
│   └── __rateLimit.mw.js  # Rate limiting
├── config/               # Configuration files
│   ├── index.config.js
│   └── envs/
│       ├── development.js
│       └── production.js
├── tests/                # Test files
└── docs/                 # Additional documentation
```

## Installation

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd axion-main
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Environment Setup:**
   Create a `.env` file in the root directory:
   ```env
   # Application
   SERVICE_NAME=school_management
   ENV=development
   USER_PORT=5111
   ADMIN_PORT=5222
   ADMIN_URL=http://localhost:5222

   # Database URLs
   MONGO_URI=mongodb://localhost:27017/school_management
   REDIS_URI=redis://127.0.0.1:6379

   # Redis configurations
   CORTEX_REDIS=redis://127.0.0.1:6379
   CORTEX_PREFIX=school_management
   CORTEX_TYPE=school_management
   OYSTER_REDIS=redis://127.0.0.1:6379
   OYSTER_PREFIX=school_management
   CACHE_REDIS=redis://127.0.0.1:6379
   CACHE_PREFIX=school_management:ch

   # Security (replace with secure random strings)
   LONG_TOKEN_SECRET=your_long_token_secret_key_here
   SHORT_TOKEN_SECRET=your_short_token_secret_key_here
   NACL_SECRET=your_nacl_secret_key_here
   ```

4. **Start Required Services:**

   For Windows:
   ```bash
   # Start MongoDB
   net start MongoDB

   # Start Redis
   redis-server
   ```

   For Linux/Mac:
   ```bash
   # Start MongoDB
   sudo systemctl start mongod

   # Start Redis
   redis-server
   ```

5. **Run the Application:**
   ```bash
   # Development mode with auto-reload
   npm run dev

   # Production mode
   npm start
   ```

## API Documentation

Access the Swagger documentation at: `http://localhost:5111/api-docs`

### Key Endpoints

#### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration

#### Schools
- `GET /api/schools` - List all schools
- `POST /api/schools` - Create a new school
- `GET /api/schools/:id` - Get school details
- `PUT /api/schools/:id` - Update school
- `DELETE /api/schools/:id` - Delete school

#### Classrooms
- `GET /api/schools/:schoolId/classrooms` - List classrooms
- `POST /api/schools/:schoolId/classrooms` - Create classroom
- `GET /api/schools/:schoolId/classrooms/:id` - Get classroom
- `PUT /api/schools/:schoolId/classrooms/:id` - Update classroom
- `DELETE /api/schools/:schoolId/classrooms/:id` - Delete classroom

#### Students
- `GET /api/schools/:schoolId/students` - List students
- `POST /api/schools/:schoolId/students` - Enroll student
- `GET /api/schools/:schoolId/students/:id` - Get student
- `PUT /api/schools/:schoolId/students/:id` - Update student
- `DELETE /api/schools/:schoolId/students/:id` - Remove student
- `POST /api/students/:id/transfer` - Transfer student

## Testing

1. **Run Tests:**
   ```bash
   # Run all tests
   npm test

   # Run specific test suite
   npm test -- tests/auth.test.js
   ```

2. **Test Coverage:**
   ```bash
   npm run test:coverage
   ```

## Error Handling

The API uses standard HTTP status codes and returns errors in the format:
```json
{
  "ok": false,
  "code": 400,
  "errors": ["Detailed error message"]
}
```

## Security Features

1. **JWT Authentication**
   - Short-lived access token (1 hour)
   - Long-lived refresh token (7 days)

2. **RBAC Implementation**
   - Superadmin: Full system access
   - School Administrator: Limited to assigned school

3. **Rate Limiting**
   - 100 requests per 15 minutes per IP

4. **Security Headers**
   - Helmet.js implementation
   - CORS configuration
   - XSS protection

## Development

1. **Code Style:**
   ```bash
   # Run linter
   npm run lint

   # Fix linting issues
   npm run lint:fix

   # Format code
   npm run format
   ```

2. **Database Management:**
   ```bash
   # Create database backup
   npm run db:backup

   # Restore database
   npm run db:restore
   ```

## Deployment

1. **Prepare for Production:**
   ```bash
   # Install production dependencies only
   npm ci --production
   ```

2. **Set Production Environment:**
   - Update `.env` with production values
   - Configure production database URLs
   - Set secure token secrets

3. **Start Application:**
   ```bash
   npm start
   ```

## Monitoring

- Application logs are stored in:
  - `logs/error.log` - Error logs
  - `logs/combined.log` - All logs
- Health check endpoint: `GET /health`

## License

ISC

## Support

For support, email [jilanin17@gmail.com]
