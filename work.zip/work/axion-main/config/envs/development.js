module.exports = {
    rateLimit: {
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: 100 // limit each IP to 100 requests per windowMs
    },
    cors: {
        origin: '*', // In production, this should be restricted
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowedHeaders: ['Content-Type', 'Authorization', 'token']
    },
    jwt: {
        shortTokenExpiry: '1h',
        longTokenExpiry: '7d'
    },
    mongodb: {
        options: {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }
    }
}