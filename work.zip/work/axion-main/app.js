const express               = require('express');
const cors                  = require('cors');
const helmet                = require('helmet');
const morgan                = require('morgan');
const config                = require('./config/index.config.js');
const Cortex                = require('ion-cortex');
const ManagersLoader        = require('./loaders/ManagersLoader.js');
const swaggerJsdoc          = require('swagger-jsdoc');
const swaggerUi             = require('swagger-ui-express');

// Connect to MongoDB
const mongoDB = config.dotEnv.MONGO_URI ? require('./connect/mongo')({
    uri: config.dotEnv.MONGO_URI
}) : null;

// Initialize cache
const cache = require('./cache/cache.dbh')({
    prefix: config.dotEnv.CACHE_PREFIX,
    url: config.dotEnv.CACHE_REDIS
});

// Initialize Cortex
const cortex = new Cortex({
    prefix: config.dotEnv.CORTEX_PREFIX,
    url: config.dotEnv.CORTEX_REDIS,
    type: config.dotEnv.CORTEX_TYPE,
    state: () => {
        return {}
    },
    activeDelay: "50ms",
    idlDelay: "200ms",
});

// Swagger configuration
const swaggerOptions = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'School Management System API',
            version: '1.0.0',
            description: 'API documentation for School Management System',
        },
        servers: [
            {
                url: `http://localhost:${config.dotEnv.USER_PORT}`,
                description: 'Development server',
            },
        ],
    },
    apis: ['./routes/*.js'], // Path to the API routes
};

const swaggerDocs = swaggerJsdoc(swaggerOptions);

// Initialize managers
const managersLoader = new ManagersLoader({ config, cache, cortex });
const managers = managersLoader.load();

// Create Express app
const app = express();

// Middleware
app.use(helmet()); // Security headers
app.use(cors(config.cors)); // CORS configuration
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies
app.use(morgan('dev')); // Request logging

// Rate limiting
app.use(managers.rateLimit());

// API Documentation
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'ok',
        timestamp: new Date(),
        service: config.dotEnv.SERVICE_NAME,
        environment: config.dotEnv.ENV
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        ok: false,
        code: 500,
        errors: 'Internal Server Error'
    });
});

// Start the server
const PORT = config.dotEnv.USER_PORT || 5111;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});

module.exports = app;
