module.exports = [
    {userId: '00boardman00',    action:'config', layer: 'board'},
    {userId: '00postman00',    action:'config', layer: 'board.post'},
    {userId: '00commentman00', action:'config', layer: 'board.post.comment'},
    {userId: '00replyman00',   action:'config', layer: 'board.post.comment.reply'}
]