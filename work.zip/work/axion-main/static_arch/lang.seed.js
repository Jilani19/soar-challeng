module.exports = [
    {
        id: 'funny',
        label: {
            ar: 'مضحك',
            en: 'Funny'
        }
    },
    {
        id: 'health',
        label: {
            ar: 'صحة',
            en: 'Health'
        }
    },
]