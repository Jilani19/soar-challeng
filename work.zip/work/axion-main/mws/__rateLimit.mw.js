const rateLimit = require('express-rate-limit');

module.exports = ({ meta, config }) => {
    return rateLimit({
        windowMs: config.rateLimit.windowMs,
        max: config.rateLimit.max,
        message: {
            ok: false,
            code: 429,
            errors: 'Too many requests, please try again later.'
        },
        standardHeaders: true,
        legacyHeaders: false
    });
} 