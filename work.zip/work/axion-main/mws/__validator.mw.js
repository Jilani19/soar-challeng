const Joi = require('joi');

module.exports = ({ meta, config, managers }) => {
    return ({ schema }) => {
        return async (req, res, next) => {
            try {
                const validationSchema = Joi.object(schema);
                await validationSchema.validateAsync(req.body);
                next();
            } catch (error) {
                return managers.responseDispatcher.dispatch(res, {
                    ok: false,
                    code: 400,
                    errors: error.details.map(detail => detail.message)
                });
            }
        };
    };
}; 