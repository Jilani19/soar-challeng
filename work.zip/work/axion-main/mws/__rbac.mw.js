module.exports = ({ meta, config, managers }) => {
    return ({ req, res, next, allowedRoles }) => {
        if (!req.headers.token) {
            return managers.responseDispatcher.dispatch(res, { ok: false, code: 401, errors: 'unauthorized' });
        }

        let decoded = null;
        try {
            decoded = managers.token.verifyShortToken({ token: req.headers.token });
            if (!decoded) {
                return managers.responseDispatcher.dispatch(res, { ok: false, code: 401, errors: 'unauthorized' });
            }

            // Check if user's role is allowed
            if (!allowedRoles.includes(decoded.role)) {
                return managers.responseDispatcher.dispatch(res, { ok: false, code: 403, errors: 'forbidden' });
            }

            // For school_admin, check if they're accessing their own school's resources
            if (decoded.role === 'school_admin' && req.params.schoolId && decoded.schoolId !== req.params.schoolId) {
                return managers.responseDispatcher.dispatch(res, { ok: false, code: 403, errors: 'forbidden' });
            }

        } catch (err) {
            return managers.responseDispatcher.dispatch(res, { ok: false, code: 401, errors: 'unauthorized' });
        }

        next(decoded);
    }
} 